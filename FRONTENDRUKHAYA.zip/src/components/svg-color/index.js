export { default } from './SvgColor';
