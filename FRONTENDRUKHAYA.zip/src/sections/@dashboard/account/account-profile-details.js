import React, { useState, useEffect, useCallback } from 'react';
import {
  Box,
  Button,
  Card,
  CardActions,
  CardContent,
  CardHeader,
  Divider,
  Grid,
  TextField,
} from '@mui/material';

const AccountProfileDetails = () => {
  const [values, setValues] = useState({
    name: '',
    email: '',
    gender: '',
    dob: '',
    height: '',
    weight: '',
    goal: '',
    body_temp: '',
    pulse_rate: '',
    resp_rate: '',
    blood_pressure: '',
  });

  const handleChange = (event) => {
    setValues((prevState) => ({
      ...prevState,
      [event.target.name]: event.target.value,
    }));
  };

  const handleSubmit = async (event) => {
    event.preventDefault();
    await updateProfileDetails();
  };

  const getProfileDetails = useCallback(async () => {
    try {
      const response = await fetch('https://final-backend-tc2r.onrender.com/api/traineeprofile/gettraineeprofile', {
        method: 'GET',
        mode: 'cors',
        headers: {
          'Content-Type': 'application/json',
          'auth-token': localStorage.getItem('usertoken'),
        },
      });
  
      const data = await response.json();
      console.log(data);
  
      setValues(data); // Set the entire response data as the values object
  
    } catch (error) {
      console.error(error);
    }
  }, []);
  

  const updateProfileDetails = useCallback(async () => {
    try {
      const response = await fetch('https://final-backend-tc2r.onrender.com/api/traineeprofile/updatetraineeprofile', {
        method: 'PUT',
        mode: 'cors',
        headers: {
          'Content-Type': 'application/json',
          'auth-token': localStorage.getItem('usertoken'),
        },
        body: JSON.stringify(values),
      });
      console.log(values);
      const data = await response.json();
      console.log('Updated profile details:', data);
      alert(data.message);
    } catch (error) {
      console.error(error);
    }
  }, [values]);

  useEffect(() => {
    getProfileDetails();
  }, [getProfileDetails]);


  return (
    <form autoComplete="off" noValidate onSubmit={handleSubmit}>
      <Card>
        <CardHeader subheader="The information can be edited"  /><br/>
        <CardContent sx={{ pt: 0 }}>
          <Box sx={{ m: -1.5 }}>
            <Grid container spacing={3}>
              <Grid item xs={12} md={6}>
                <TextField
                  fullWidth
                //   helperText="Please specify the first name"
                  label="Name"
                  name="name"
                  onChange={handleChange}
                  required
                  value={values.name}/>
              </Grid>
              
              <Grid item xs={12} md={6}>
                <TextField
                  fullWidth
                  label="Email Address"
                  name="email"
                  onChange={handleChange}
                  required
                  value={values.email}
                />
              </Grid>
              <Grid item xs={12} md={6}>
                <TextField
                  fullWidth
                  label="Gender"
                  name="gender"
                  onChange={handleChange}
                  required
                  value={values.gender}
                />
              </Grid>
              <Grid item xs={12} md={6}>
                <TextField
                  fullWidth
                  label="DoB"
                  name="dob"
                  onChange={handleChange}
                  required
                  value={values.dob}
                />
                   </Grid>

              <Grid item xs={12} md={6}>
                <TextField
                  fullWidth
                  label="Height"
                  name="height"
                  onChange={handleChange}
                  required
                  type="number"
                  value={values.height}
                />
              </Grid>
              <Grid item xs={12} md={6}>
                <TextField
                  fullWidth
                  label="Weight"
                  name="weight"
                  onChange={handleChange}
                  required
                  type="number"
                  value={values.weight}
                />
              </Grid>
              {/* Add the remaining fields here */}
              <Grid item xs={12} md={6}>
                <TextField
                  fullWidth
                  label="Goal"
                  name="goal"
                  onChange={handleChange}
                  required
                  value={values.goal}
                />
              </Grid>
              <Grid item xs={12} md={6}>
                <TextField
                  fullWidth
                  label="Body Temperature"
                  name="body_temp"
                  onChange={handleChange}
                  required
                  type="number"
                  value={values.body_temp}
                />
              </Grid>
              <Grid item xs={12} md={6}>
                <TextField
                  fullWidth
                  label="Pulse Rate"
                  name="pulse_rate"
                  onChange={handleChange}
                  required
                  type="number"
                  value={values.pulse_rate}
                />
              </Grid>
              <Grid item xs={12} md={6}>
                <TextField
                  fullWidth
                  label="Respiratory Rate"
                  name="resp_rate"
                  onChange={handleChange}
                  required
                  type="number"
                  value={values.resp_rate}
                />
              </Grid>
              <Grid item xs={12} md={6}>
                <TextField
                  fullWidth
                  label="Blood Pressure"
                  name="blood_pressure"
                  onChange={handleChange}
                  required
                  type="number"
                  value={values.blood_pressure}
                />
              </Grid>
            </Grid>
          </Box>
        </CardContent>
        <Divider />
        <CardActions>
          <Button color="primary" variant="contained" type="submit">
            Save changes
          </Button>
        </CardActions>
      </Card>
    </form>
  );
};

export default AccountProfileDetails;

