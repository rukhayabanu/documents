// import { combineReducers, configureStore } from '@reduxjs/toolkit';
// // import { createStore } from "redux";

// import {composeWithDevTools} from 'redux-devtools-extension';
// import questionReducer from './question_reducer';
// import resultReducer from './result_reducer';
// import shopReducer from "./shopReducer";

// // const store = createStore(shopReducer,composeWithDevTools());
// const rootReducer = combineReducers({
//     questions : questionReducer,
//     result : resultReducer,
//     shop: shopReducer
// })
// const store = configureStore({ reducer : rootReducer});
// export default store;

// Changes made by S

import { combineReducers, configureStore } from '@reduxjs/toolkit';
import questionReducer from './question_reducer';
import resultReducer from './result_reducer';
import shopReducer from './shopReducer';

const rootReducer = combineReducers({
  questions: questionReducer,
  result: resultReducer,
  shop: shopReducer,
});

const store = configureStore({
  reducer: rootReducer,
  devTools: true,
});

export default store;
