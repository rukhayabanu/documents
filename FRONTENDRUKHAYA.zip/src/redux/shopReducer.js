import * as actionTypes from './actionTypes';
import dumbell from '../images/dumbell.jpg';
import shoe from '../images/shoe.jpg';
import proteinShake from '../images/proteinShake.jpg';

const initialState = {
    products : [
        {
          id: 1,
          title: "Shoe",
          description:
            `When it comes down to it, so to speak, shoes can make or break your gym or home workout experience. Training ill-equipped can leave you disinterested, uncomfortable and, worst case, injured. To get the most out of your exercise regimen, it's best to have a go-to pair of gym shoes.`,
          price: 2000,
          image:shoe,
        },
        {
          id: 2,
          title: "Protein Shake",
          description:
              `Protein blends are exactly what's said on the tin — a blend of different types of nutrients and protein. If you're looking to get a little more than usual from your protein shake, then they're often topped up with extra nutrients.Protein shakes are made from protein powder, which is a dry, powdered supplement that can be derived from both animal or plant-based protein sources. It can be flavoured or unflavoured, and is most often mixed with water, milk, or another liquid as part of a protein shake or smoothie. `,
          price: 999.0,
          image:proteinShake,
        },
        {
          id: 3,
          title: "Dumbell",
          description:
            `This set of adjustable dumbbells is bundled with a weight bench for you to have a solid set up for your at home weight sessions. The dumbbells adjust from 5 pounds to 25 pounds in 5-pound increments, and the bench has seven adjustable back settings and three adjustable seat positions. The bundle is an efficient and budget-savvy way to elevate your home workout experience without breaking the bank.`,
          price: 750.0,
          image:dumbell
        },
      ],
    cart : [],
    currentItem : {}
}

const shopReducer = (state=initialState,action) => {
    switch(action.type){
        case actionTypes.ADD_TO_CART :
            {const item = state.products.find((product)=>product.id===action.payload)        
            const inCart = state.cart.find((product)=>product.id===action.payload)
            console.log(inCart);
            return {
                ...state,
                cart : inCart?
                       state.cart.map((item)=>item.id===action.payload.id?{...item,qty:item.qty+1}:item) :
                       [...state.cart,{...item,qty:1}] 
            }}
            // if (inCart && inCart.qty) {
            //   // Update the quantity of the existing item in the cart
            //   return {
            //     ...state,
            //     cart: state.cart.map((item) =>
            //       item.id === action.payload.id ? { ...item, qty: item.qty + 1 } : item
            //     ),
            //   };
            // } else {
            //   // Add a new item to the cart with a quantity of 1
            //   return {
            //     ...state,
            //     cart: [...state.cart, { ...item, qty: 1 }],
            //   };
            // }}
        case actionTypes.REMOVE_FROM_CART : 
            {return{
                ...state,
                cart : state.cart.filter((product)=>product.id !== action.payload.item.id)
                
            }}
        case actionTypes.ADJUST_QTY : 
            {return {
                ...state,
                cart : state.cart.map((product)=>product.id===action.payload.id?{...product,qty:action.payload.qty}:product)
            }}
        case actionTypes.LOAD_CURRENT_ITEM : 
            { 
              return {
                ...state,
                currentItem : action.payload.item
            }}
        default : {return state} 
    }
}

export default shopReducer