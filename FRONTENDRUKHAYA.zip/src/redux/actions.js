import {
    ADD_TO_CART,
    REMOVE_FROM_CART,
    ADJUST_QTY,
    LOAD_CURRENT_ITEM,
  } from './actionTypes';
  
  export const addToCart = (id) => {
    return {
      type: ADD_TO_CART,
      payload: {
        id,
      },
    };
  };
  
  export const removeFromCart = (productId) => {
    return {
      type: REMOVE_FROM_CART,
      payload: {
        id: productId,
      },
    };
  };
  
  export const adjustQty = (productId, newQty) => {
    return {
      type: ADJUST_QTY,
      payload: {
        id: productId,
        quantity: newQty,
      },
    };
  };
  
  export const loadCurrentItem = (item) => {
    return {
      type: LOAD_CURRENT_ITEM,
      payload: {
        item,
      },
    };
  };
  