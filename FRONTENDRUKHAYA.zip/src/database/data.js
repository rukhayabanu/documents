export default [
    {
        id: 1,
        question : "1. What is your current blood pressure reading?",
        options : [
            '120/80',
            '140/90',
            '160/100',
            '180/110',
        ]
    },
    {
        id: 2,
        question : "2.  Which of the following BMI ranges best matches your current body composition?",
        options : [
            'Under 18.5 (Underweight)',
            '18.5 - 24.9 (Normal)',
            '25 - 29.9 (Overweight)',
            '30 or greater (Obese)',
        ]
    },
    {
        id: 3,
        question : "3. How often do you consume fruits and vegetables in your daily diet?",
        options : [
            'At every meal',
            'Once a day',
            'A few times a week',
            'Rarely or never'
        ]
    },
    {
        id: 4,
        question : "4. How often do you consume sugary soft drinks in your daily diet?",
        options : [
            'At every meal',
            'Once a day',
            'A few times a week',
            'Rarely or never'
        ]
    },
    {
        id: 5,
        question : "5. How much of time do you engage in moderate-intensity aerobic activity each week?",
        options : [
            '30 minutes',
            '60 minutes',
            '90 minutes',
            '120 minutes',
        ]
    },
    {
        id: 6,
        question : "6. What is your current resting pulse rate?",
        options : [
            'Less than 50 bpm',
            '51-59 bpm',
            '60-100 bpm',
            'More than 100 bpm',
        ]
    },
    {
        id: 7,
        question : "7. Which of the following carbohydrates do you regularly consume in your diet?",
        options : [
            'Whole grain breads and pastas',
            'Sugary snacks and desserts',
            'White bread and rice',
            "I don't consume carbohydrates",
        ]
    },
    {
        id: 8,
        question : "8. How many hours of sleep do you typically get each night?",
        options : [
            '4-5 hours',
            '6-7 hours',
            '8-9 hours',
            "10+ hours",
        ]
    },
    {
        id: 9,
        question : "9. Which of the following is the most common source of protein in your diet?",
        options : [
            'Meat and poultry',
            'Fish and seafood',
            'Plant-based sources',
            "I don't eat protein-rich foods",
        ]
    },
    {
        id: 10,
        question : "10. What is your average respiration rate per minute during rest?",
        options : [
            '12-16 breaths per minute',
            '8-11 breaths per minute',
            '17-20 breaths per minute',
            "21 or more breaths per minute",
        ]
    },


];

export const answers = [0, 1, 0, 3, 1, 2, 0, 2, 0, 0];