// ----------------------------------------------------------------------

const account = {
  // displayName: 'XYZ',
  // email: 'demo@minimals.cc',
  photoURL: '/assets/images/avatars/avatar_default.jpg',
};

export default account;
