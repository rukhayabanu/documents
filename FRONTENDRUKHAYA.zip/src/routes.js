import { Navigate, useRoutes,Routes,Route } from 'react-router-dom';

import { connect } from "react-redux";
// layouts
import DashboardLayout from './layouts/dashboard';
import AdminDashboardLayout from './layouts/adminDashboard';
import TrainerDashboard from './layouts/trainerDashboard';
import SimpleLayout from './layouts/simple';
//
import Appp from './pages/Appp'
import Page404 from './pages/Page404';
import Subscription from './pages/Subscription';
import Account from './pages/Accountt';
import Sessions from './pages/Session';
import Bmi from './pages/Bmi';
import DashboardAppPage from './pages/DashboardAppPage';
import AdminDashboardAppPage from './pages/AdminDashboardAppPage';
import TrainerDashboardAppPage from './pages/TrainerDashboardAppPage';

import AdminLogin from './pages/AdminLogin';
import Home1 from './pages/Home1';
import ContactUs from './pages/ContactUs';
import Booking from './pages/booking'
import Signup from './pages/TestSignup';
import TrainerLogin from './pages/TrainerLogin';
import TrainerSignup from './pages/TrainerSignup';
import TraineeSignup from './pages/TraineeSignup';
import TraineeLogin from './pages/TraineeLogin';
import FetchTrainers from './pages/FetchTrainers';
import FetchTrainees from './pages/FetchTrainees';
import FAQFormAdmin from './pages/FaqFormAdmin';
import FetchFaqAdmin from './pages/FetchFaqAdmin';
import FetchAllFaqs from './pages/FetchAllFaqs';
import AttendanceForm from './pages/Attendance';
import BuySubscription from './pages/BuySubscription'
// Changes

// import { Provider } from 'react-redux';
// import store from '../redux/store';
import Main from './pages/Main';
import Quiz from './pages/Quiz';
import Result from './pages/Result';
import { CheckUserExist } from './helper/helper';


import Navbar from "./pages/NavbarShop";
import Products from "./pages/Products";
import Cart from "./pages/Cart";
import SingleItem from "./pages/SingleItem";







// ----------------------------------------------------------------------



const Router=()=>{
  return(

    <Routes>
      <Route exact path="*" element={<Home1/>} />
        <Route exact path="/contactus" element={<ContactUs/>} />
        <Route exact path="/booking" element={<Booking/>} />
        <Route exact path="/trainerlogin" element={<TrainerLogin/>} />
        <Route exact path="/trainersignup" element={<TrainerSignup/>} />
        <Route exact path="/traineesignup" element={<TraineeSignup/>} />
        <Route exact path="/traineelogin" element={<TraineeLogin/>} />
        <Route exact path="/adminlogin" element={<AdminLogin/>} />
        <Route exact path="/faq" element={<FetchAllFaqs/>} />

        <Route exact path="/mainquiz" element={<Main />} />
        <Route exact path="/quiz" element={<CheckUserExist><Quiz /></CheckUserExist>} />
        <Route exact path="/result" element={<CheckUserExist><Result /></CheckUserExist>} />

        <Route exact path="/shop" element={<Products/>} />
        <Route exact path="/cart" element={<Cart/>} />
        {/* {!current ? 
            <Navigate to="/shop" />
           : 
            <Route exact path="/product/:id" element={<SingleItem/>}/>
          } */}
        <Route exact path="/product/:id" element={<SingleItem />} />
      
    <Route path="/dashboardtrainee/*" element={<DashboardLayout />} >
          <Route path="app"  element={<DashboardAppPage />}/>
          <Route path="bmi"  element={<Bmi />} />
          <Route path="subscription"  element={<Subscription />} />
          <Route path="sessions"  element={<Sessions />} />
          <Route path="booksessions"  element={<Booking />} />
          <Route path="profile"  element={<Account />} />
          <Route path="attendance"  element={<AttendanceForm />} />
          <Route path="buysubscription"  element={<BuySubscription />} />
       </Route>

       <Route path="/dashboardtrainer/*" element={<DashboardLayout />} >
          <Route path="app"  element={<TrainerDashboardAppPage />}/>
          <Route path="bmi"  element={<Bmi />} />
          <Route path="subscription"  element={<Subscription />} />
          <Route path="sessions"  element={<Sessions />} />
          <Route path="profile"  element={<Account />} />
          <Route path="attendance"  element={<Account />} />
          <Route path="logout"  element={<Account />} />
       </Route>
       <Route path="/dashboardadmin/*" element={<AdminDashboardLayout />} >
          <Route path="app"  element={<AdminDashboardAppPage />}/>
          <Route path="trainees"  element={<FetchTrainees />} />
          <Route path="trainers"  element={<FetchTrainers />} />
          <Route path="faqformadmin" element={<FAQFormAdmin/>} />
          <Route path="faqsbyadmin" element={<FetchFaqAdmin/>} />
       </Route>

    </Routes>

    
    
  
  )
}

const mapStateToProps = (state) => {
  return{
    current : state.currentItem
  }
}

export default connect(mapStateToProps);

export {Router};