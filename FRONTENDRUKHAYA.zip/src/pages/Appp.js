import './styles/Appp.css';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom'
import { Provider } from 'react-redux';
import store from '../redux/store';
import Main from './Main';
import Quiz from './Quiz';
import Result from './Result';
import { CheckUserExist } from '../helper/helper';

// const router = createBrowserRouter([
//   {
//   path : '/',
//   element: <Main />
//   },
//   {
//     path : '/quiz',
//     element: <CheckUserExist><Quiz /></CheckUserExist>
//   },
//   {
//     path : '/result',
//     element: <CheckUserExist> <Result /> </CheckUserExist> 
//   },
// ])
function Appp() {
  return (
    
    <Provider store={store}>
      {/* <Router> */}
        <Routes>
          <Route exact path="/mainquiz" element={<Main />} />
          <Route exact path="/quiz" element={<CheckUserExist><Quiz /></CheckUserExist>} />
          <Route exact path="/result" element={<CheckUserExist><Result /></CheckUserExist>} />
        </Routes>
      {/* </Router> */}
    </Provider>
   
  );
}

export default Appp;