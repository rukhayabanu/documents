import {React,useState} from 'react'
import './styles/contactus.css'
import { useNavigate} from 'react-router-dom'

function ContactUs() {
  const nevigate = useNavigate();
  const [credentials, setCredentials] = useState({name:"",email:"",subject:"",description:""})

  const handleSubmit=async(e)=>{
    e.preventDefault();
    const{name,email,subject,description}=credentials;
    const response = await fetch(`https://localhost:7000/api/contact`, {
        method: "POST",
        mode: "cors",
        headers: {
          "Content-Type": "application/json"
        },
    body:JSON.stringify({name,email,subject,description})
});

  const json =await response.json()
  console.log(json)
  alert(json.message);
}

 const onChange=(e)=>{
  setCredentials({...credentials,[e.target.name]:e.target.value})
}

return (

 <div className="new_home_web">
  <div className="responsive-container-block big-container">
    <img className="imgBG" alt=""src="https://workik-widget-assets.s3.amazonaws.com/widget-assets/images/aw65.png" />
      <div className="responsive-container-block textContainer">
        <div className="topHead">
          <p className="text-blk heading">
            CONTACT US
          </p>
            <div className="orangeLine" id="w-c-s-bgc_p-2-dm-id"/>
        </div>
        <p className="text-blk subHeading"/>
      </div>
      <div className="responsive-container-block container">
        <div className="responsive-cell-block wk-tab-12 wk-mobile-12 wk-desk-7 wk-ipadp-10 line" id="i69b">
          <form className="form-box">
            <div className="container-block form-wrapper">
              <div className="responsive-container-block">
                <div className="left4">
                  <div className="responsive-cell-block wk-ipadp-6 wk-tab-12 wk-mobile-12 wk-desk-6" id="i10mt-2">
                    <input className="input" id="ijowk-2" name="name" value={credentials.name} onChange={onChange} placeholder="Name" />
                  </div>
                  <div className="responsive-cell-block wk-desk-6 wk-ipadp-6 wk-tab-12 wk-mobile-12">
                    <input className="input" id="ipmgh-2" name="email" value={credentials.email} onChange={onChange} placeholder="Email Address" />
                  </div>
                  <div className="responsive-cell-block wk-desk-6 wk-ipadp-6 wk-tab-12 wk-mobile-12 lastPhone">
                    <input className="input" id="imgis-2" name="subject" value={credentials.subject} onChange={onChange} placeholder="Subject" />
                  </div>
                </div>
                <div className="responsive-cell-block wk-tab-12 wk-mobile-12 wk-desk-12 wk-ipadp-12" id="i634i-2">
                  <textarea className="textinput" id="i5vyy-2" name="description" value={credentials.description} onChange={onChange} placeholder="Description" defaultValue={""} />
                </div>
              </div>
              <a className="send" onClick={handleSubmit} href="#" id="w-c-s-bgc_p-1-dm-id">Send</a>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
);
}
export default ContactUs;