import { Helmet } from 'react-helmet-async';
import { faker } from '@faker-js/faker';
// @mui
import { useTheme } from '@mui/material/styles';
import { Grid, Container, Typography } from '@mui/material';
// components
import Iconify from '../components/iconify';
// sections
import {
  AppTasks,
  AppNewsUpdate,
  AppOrderTimeline,
  AppCurrentVisits,
  AppWebsiteVisits,
  AppTrafficBySite,
  AppWidgetSummary,
  AppCurrentSubject,
  AppConversionRates,
} from '../sections/@dashboard/app';

// ----------------------------------------------------------------------

export default function AdminDashboard() {
  const theme = useTheme();

  return (
    <>
      <Helmet>
        <title> Dashboard </title>
      </Helmet>

      <Container maxWidth="xl">
        <Typography variant="h4" sx={{ mb: 5 }}>
          Hi Admin, Welcome back
        </Typography>

        <Grid container spacing={3}>
          <Grid item xs={12} sm={6} md={3}>
            <AppWidgetSummary title="Number Of Users" icon={'carbon:user-activity'} />
          </Grid>
          <Grid item xs={12} sm={6} md={3}>
            <AppWidgetSummary title=" Number Of Tranier "  color="info" icon={'mdi:user'} />
          </Grid>
          <Grid item xs={12} sm={6} md={3}>
            <AppWidgetSummary title="Revenue"  color="warning" icon={'mdi-light:currency-gbp'} />
          </Grid>
          <Grid item xs={12} sm={6} md={3}>
            <AppWidgetSummary title="Subscription Types"  color="error" icon={'mdi-light:tag'} />
          </Grid>
         
        </Grid>
        
        <button style={{ marginLeft:"30vw", borderRadius:"15px", padding: "10px", marginTop:"2vh", background:"red" }} >
<a href="https://charts.mongodb.com/charts-project-0-btnmj/public/dashboards/645e0b11-6e2f-4590-813b-41609f5cfdb4"
  style={{ color: 'white' }}
>
{' '}Analytics</a></button>

</Container>
    </>
  );
}
