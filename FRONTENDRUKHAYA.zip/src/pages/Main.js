import React, { useRef } from 'react'
import { useDispatch } from 'react-redux'
import { Link } from 'react-router-dom'
import { setUserId } from '../redux/result_reducer'
import './styles/Main.css'

export default function Main() {
  const inputRef = useRef(null)
  const dispatch = useDispatch()

  function startQuiz(){
    if(inputRef.current?.value){
      dispatch(setUserId(inputRef.current?.value))

    }

  }

  return (
    <div className = 'q_container'>
      <h1 className='q_title q_text_dark'>FITNESS ASSESSMENT</h1>
      <p>Welcome to the NovaFit Fitness Assessment! </p>
      <p>The assessment is designed to help you assess your current level of fitness and to improve your overall health.
      Select the option that best describes your current situation.</p>
      <p>So, let's get started and learn more about your fitness level!</p>
    <form id="q_form">

    <input ref={inputRef} className = "q_userid" type="text" placeholder='Username' />
    </form>
    <div className='q_start'>
            <Link className='q_btn' to={'/quiz'} onClick = {() => startQuiz()}>START</Link>
        </div>


    </div>
  )
}
