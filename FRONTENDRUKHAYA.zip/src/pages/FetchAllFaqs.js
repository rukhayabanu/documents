import React, {useState, useEffect} from 'react'
import './styles/Faq.css'

import { Container, Accordion, AccordionSummary, AccordionDetails, Typography } from "@mui/material";

const FetchAllFaqs = () => {
  
    const [faqs, setFaq] = useState([])
    useEffect(() => {
        
            const getFaq = async () => { // API Call
              
                const response = await fetch(`https://localhost:7000/api/faq/fetchallfaq`, {
                    method: 'GET',
                    mode: "cors",
                    
                });

                const json = await response.json()
                setFaq(json);
            }
            getFaq();
        },[]);
    


    return (
        
<Container maxWidth="md">
      <Typography variant="h3" align="center" gutterBottom>
          <br /> <br />   
          Frequently Asked Questions 
      </Typography>
      {faqs.map((faq) => (
        <Accordion key={faq._id} >
          <AccordionSummary  sx={{ backgroundColor: "primary.main", color: "primary.contrastText", "&.Mui-expanded": { backgroundColor: "secondary.main" } }}>
            <Typography variant="h5" fontWeight="bold">
              {faq.question}
            </Typography>
          </AccordionSummary>
            <AccordionSummary className="faq-accordion" sx={{ backgroundColor: "primary.main", color: "primary.contrastText", "&.Mui-expanded": { backgroundColor: "secondary.main" } }}>
              <Typography variant="subtitle1">
                {faq.answer}
              </Typography>
            </AccordionSummary>
          {faq.tag && (
            <AccordionSummary className="faq-accordion" sx={{ backgroundColor: "primary.main", color: "primary.contrastText", "&.Mui-expanded": { backgroundColor: "secondary.main" } }}>
              <Typography variant="subtitle1">
                Tag: {faq.tag}
              </Typography>
            </AccordionSummary>
          )}
        </Accordion>
      ))}
    </Container>
  );
};


export default FetchAllFaqs;
