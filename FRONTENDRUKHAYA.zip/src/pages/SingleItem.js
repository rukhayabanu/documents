// import React from "react";
// import Button from '@mui/material/Button';
// import { connect } from "react-redux";
// import ShoppingCartOutlinedIcon from '@mui/icons-material/ShoppingCartOutlined';
// import styles from "./styles/SingleItem.css";

// // import { addToCart } from "../../redux/Shopping/shopping-actions";

// import * as actionTypes from '../redux/actionTypes';
// import NavbarShop from "./NavbarShop";

// const SingleItem = ({current, addToCart}) => {
//   console.log("logging current", current)

//   if (!current) {
//     return <div>Loading...</div>; // Show loading state if current item is not available yet
//   }

//   return (
//     <>
//     <NavbarShop/>
//     <div className="s-container">
//       <div className='s_img-container'>
//       <img
//         className="s_img"
//         src={current.image}
//         alt={current.title}
//       />
//       </div>
//       <div className="S_detailss">
//         <h1 className='s_p-name' >{current.title}</h1>
//         <p style={{color:'#d63031', marginBottom:'5%'}}><span style={{color:'grey'}}>M.R.P.</span>&nbsp; ₹ {current.price}</p>
//         <h4 style={{color:'#2d3436', marginBottom:'4%'}}>Description</h4>
//         <p className='s_description'>{current.description}</p>
        

//         {/* <Button style={{backgroundColor:'#e67e22', marginTop:'5%'}}
//           onClick={()=>addToCart(current.id)}
//           className={styles.details__addBtn}
//         > */}
//         <Button sx={{backgroundColor:'#e67e22', marginTop:'5%'}}
//           onClick={()=>addToCart(current.id)}
//           className={styles.details__addBtn}
//         >

//           <ShoppingCartOutlinedIcon/>&nbsp;
//           Add To Cart
//         </Button>
//       </div>
//     </div>
//     </>
//   );
// };

// // const mapStateToProps = (state) => {
// //   console.log("logging state", state)

// //   return{
// //     current : state.shop.currentItem
// //   }
// // }

// const mapStateToProps = (state) => ({
//   current: state.shop.currentItem,
// });

// // export default connect(mapStateToProps)(SingleItem);

// // const mapDispatchToProps = (dispatch) => {
// //   return{
// //     addToCart : (id) => dispatch({type:actionTypes.ADD_TO_CART,payload:{id:id}})
// //   }
// // }

// const mapDispatchToProps = (dispatch) => ({
//   addToCart(id) {
//     dispatch({type: actionTypes.ADD_TO_CART, payload: {id}});
//   },
// });

// export default connect(mapStateToProps,mapDispatchToProps)(SingleItem);




import React from "react";
import Button from '@mui/material/Button';
import { connect } from "react-redux";
import ShoppingCartOutlinedIcon from '@mui/icons-material/ShoppingCartOutlined';
import styles from "./styles/SingleItem.css";
import NavbarShop from "./NavbarShop";
import { addToCart } from "../redux/actions";

const SingleItem = ({ current, addToCart }) => {
  console.log("logging current", current);

  if (!current) {
    return <div>Loading...</div>; // Show loading state if current item is not available yet
  }

  return (
    <>
      <NavbarShop />
      <div className="s-container">
        <div className='s_img-container'>
          <img
            className="s_img"
            src={current.image}
            alt={current.title}
          />
        </div>
        <div className="S_detailss">
          <h1 className='s_p-name'>{current.title}</h1>
          <p style={{ color: '#d63031', marginBottom: '5%' }}><span style={{ color: 'grey' }}>M.R.P.</span>&nbsp; ₹ {current.price}</p>
          <h4 style={{ color: '#2d3436', marginBottom: '4%' }}>Description</h4>
          <p className='s_description'>{current.description}</p>

          <Button sx={{ backgroundColor: '#e67e22', marginTop: '5%' }}
            onClick={() => addToCart(current.id)}
            className={styles.details__addBtn}
          >
            <ShoppingCartOutlinedIcon />&nbsp;
            Add To Cart
          </Button>
        </div>
      </div>
    </>
  );
};

const mapStateToProps = (state) => ({
  current: state.shop.currentItem,
});

const mapDispatchToProps = (dispatch) => ({
  addToCart: (id) => dispatch(addToCart(id)),
});

export default connect(mapStateToProps, mapDispatchToProps)(SingleItem);
