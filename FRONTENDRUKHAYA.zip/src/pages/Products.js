import React from "react";
import { connect } from "react-redux";
import styles from "./styles/Products.module.css";
import Product from "./Product";
import Navbar from "./NavbarShop";

const Products = ({products}) => {
  
  return (
    <>
    <Navbar />
    <div className={styles.products}>
      {products.map((product) => (
        <Product key={product.id} product={product} />
      ))}
    </div>
    </>
  );
};

// const mapStateToProps = (state) => {
//   return{
//     products : state.products
//   }
// }

const mapStateToProps = (state) => {
  return {
    products: state.shop.products
  }
}


export default connect(mapStateToProps)(Products);