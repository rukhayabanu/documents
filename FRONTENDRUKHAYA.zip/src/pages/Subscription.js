import React, {useState, useEffect} from 'react'
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import Paper from '@mui/material/Paper';




const Subscriptions = () => {
  
  const subscriptionsInitial = []
  const [subscriptions, setSubscriptions] = useState(subscriptionsInitial)
  useEffect(() => {
      if (localStorage.getItem('usertoken')) {
        console.log("hrllrlr")
          const getNotes = async () => { // API Call
            console.log("hrllrfjfjlr")
              const response = await fetch(`https://localhost:7000/api/sessions/getsubscriptions`, {
                  method: 'GET',
                  mode: "cors",
                  headers: {
                      'Content-Type': 'application/json',
                      "auth-token": localStorage.getItem('usertoken')
                  }
              });
              const json = await response.json()
              console.log(json);
              setSubscriptions(json);
          }
          getNotes();
      }
  }, [])

  return (
    <>
     
     <TableContainer component={Paper}>
                <Table sx={
                        {minWidth: 650}
                    }
                    aria-label="simple table">
                    <TableHead>
                        <TableRow>
                            <TableCell>Name</TableCell>
                            <TableCell align="right">Price</TableCell>
                            <TableCell align="right">Duration</TableCell>
                            <TableCell align="right">Sessions</TableCell>
                            <TableCell align="right">Expiry</TableCell>
                            <TableCell align="right">isActive</TableCell>
                            <TableCell align="right">Date</TableCell>
                        </TableRow>
                    </TableHead>
                    <TableBody>
          {subscriptions.map((subscription) => (
            <TableRow
              key={subscription._id}
              sx={{ '&:last-child td, &:last-child th': { border: 0 } }}
            >
              <TableCell component="th" scope="row">
                {subscription.name}
              </TableCell>
              <TableCell align="right">
                  {subscription.price}
                  </TableCell>
              <TableCell align="right">
                  {subscription.duration}
                  </TableCell>
              <TableCell align="right">
              {subscription.sessions}
                  </TableCell>
              <TableCell align="right">
              {subscription.expiry}
              </TableCell>
              <TableCell align="right">
              {subscription.isActive.toString()}
              </TableCell>
              <TableCell align="right">
              {subscription.date}
              </TableCell>
                
              
            </TableRow>
          ))} 
        </TableBody>
                </Table>
            </TableContainer>

        </>
    )
}

export default Subscriptions