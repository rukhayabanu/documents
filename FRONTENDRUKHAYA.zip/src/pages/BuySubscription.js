import React, { useState } from "react";
import Button from "@mui/material/Button";
import InputLabel from "@mui/material/InputLabel";
import MenuItem from "@mui/material/MenuItem";
import FormControl from "@mui/material/FormControl";
import Select from "@mui/material/Select";

const plans = [
  { id: 1, name: "platinum" },
  { id: 2, name: "silver" },
  { id: 3, name: "gold" },
];

const BuySubscription = () => {
  const [selectedPlan, setSelectedPlan] = useState("");

  const handlePlanChange = (event) => {
    setSelectedPlan(event.target.value);
  };

//   const handlePayClick = () => {
//     const requestOptions = {
//       method: "POST",
//       headers: {
//            "Content-Type": "application/json"
//          },
//       body: JSON.stringify({ plan: selectedPlan }),
//     };
//     fetch("http://localhost:7000/buySubscription", requestOptions)
//       .then((response) => response.json())
//       .then((data) => console.log(data));
//   };
const handlePayClick = async () => { // API Call
              
    const response = await fetch(`https://localhost:7000/api/subscription/buySubscription`, {
        method: 'POST',
        mode: "cors",
        headers: {
            'Content-Type': 'application/json',
            "auth-token": localStorage.getItem('usertoken')
        },
        body: JSON.stringify({ plan: selectedPlan }),
    });

    const json = await response.json()
    alert(json.message);
}

  return (
    <div>
      <FormControl sx={{ m: 1, minWidth: 120 }}>
        <InputLabel id="plan-label">Plan</InputLabel>
        <Select
          labelId="plan-label"
          id="plan"
          value={selectedPlan}
          label="Plan"
          onChange={handlePlanChange}
        >
          {plans.map((plan) => (
            <MenuItem key={plan.id} value={plan.name}>
              {plan.name}
            </MenuItem>
          ))}
        </Select>
      </FormControl><br/>
      <br/>
      <Button onClick={handlePayClick} variant="contained">
        Pay
      </Button>
    </div>
  );
};

export default BuySubscription;
