import React, {useState, useEffect} from 'react'
import './styles/Faq.css'


import { Container, Accordion, AccordionSummary, AccordionDetails, Typography } from "@mui/material";

const FetchFaqAdmin = () => {
  
    const [faqs, setFaq] = useState([])
    useEffect(() => {
        
            const getFaq = async () => { // API Call
              
              
                const response = await fetch(`https://localhost:7000/api/faq/fetchfaq`, {
                    method: 'GET',
                    mode: "cors",
                    // headers: {
                    //     "auth-token": localStorage.getItem('admintoken')
                    // }
                });

                const json = await response.json()
                setFaq(json);
            }
            getFaq();
        },[]);
    


    return (
  
    <Container maxWidth="md">
      <Typography variant="h3" align="center" gutterBottom>
        FAQs
      </Typography>
      {faqs.map((faq) => (
        <Accordion key={faq._id} >
          <AccordionSummary  sx={{ backgroundColor: "primary.main", color: "primary.contrastText", "&.Mui-expanded": { backgroundColor: "secondary.main" } }}>
            <Typography variant="h5" fontWeight="bold">
              {faq.question}
            </Typography>
          </AccordionSummary>
            <AccordionSummary className="faq-accordion" sx={{ backgroundColor: "primary.main", color: "primary.contrastText", "&.Mui-expanded": { backgroundColor: "secondary.main" } }}>
              <Typography variant="subtitle1">
                {faq.answer}
              </Typography>
            </AccordionSummary>
          {faq.tag && (
            <AccordionSummary className="faq-accordion" sx={{ backgroundColor: "primary.main", color: "primary.contrastText", "&.Mui-expanded": { backgroundColor: "secondary.main" } }}>
              <Typography variant="subtitle1">
                Tag: {faq.tag}
              </Typography>
            </AccordionSummary>
          )}
        </Accordion>
      ))}
    </Container>
  );
};


export default FetchFaqAdmin;
