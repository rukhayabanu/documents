import React from "react"
import './styles/booking.css'

function FaqFormAdmin() {

    const addFaq = async (e) => {
        e.preventDefault();
    
        // Get form data
        const form = e.target;
        const formData = new FormData(form);

       
            //   const jsonData = {};
            //   for (const [key, value] of formData.entries()) {
            //     jsonData[key] = value;
            //       }
        const jsonData = {};
        formData.forEach((value, key) => {
        jsonData[key] = value;
});
  const response = await fetch(`https://localhost:7000/api/faq/addfaq`, {
  method: 'POST',
  mode : "cors",
  headers: {
      'content-type':'application/json',
      // 'auth-token': localStorage.getItem('admintoken')
    },
    body: JSON.stringify(jsonData)
  });
  const json=await response.json();
  alert(json.message);
}


    return (
        <div className="formbold-main-wrapper">
            <div className="formbold-form-wrapper">
                 <br/> <br/> <br/>
                <form  onSubmit={()=>addFaq()}>                   
                    
                    <div className="formbold-mb-5 formbold-pt-3">
                      <div className="flex flex-wrap formbold--mx-3">
                        <div className="w-full  formbold-px-3">
                          <div className="formbold-mb-5">
                            <label htmlFor="Question">
                              <input type="text" name="question" id="question" placeholder="Enter question" className="formbold-form-input" />
                            </label>
                          </div>
                        </div>
                       
                        <div className="w-full  formbold-px-3">
                          <div className="formbold-mb-5">
                            <label htmlFor="Answer">
                              <input type="text" name="answer" id="answer" placeholder="Enter answer" className="formbold-form-input" />
                            </label>
                          </div>
                        </div>
                        
                        <div className="w-full  formbold-px-3">
                          <div className="formbold-mb-5">
                            <label htmlFor="Tag">
                              <input type="text" name="tag" id="tag" placeholder="Enter tag" className="formbold-form-input" />
                            </label>
                          </div>
                        </div>
                      </div>
                    </div>
                  <div>
                    <button className="formbold-btn">Add FAQ</button>
                  </div>
                </form>
              </div>
            </div>
    );

}

export default FaqFormAdmin;