import './styles/Result.css';
import { Link } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import { earnPointsNumber, flagResult } from '../helper/helper';
import { resetAllAction } from '../redux/question_reducer';
import { resetResultAction } from '../redux/result_reducer';

export default function Result() {

    const dispatch = useDispatch();
    const { questions: { queue, answers }, result: { result, userId } } = useSelector(state => state);
    const totalPoints = queue.length * 10;
    const earnPoints = earnPointsNumber(result, answers, 10);
    const flag = flagResult(totalPoints, earnPoints);
    
    const analysisMessage = flag ? (
        <div className='q_message'>
            <p>Congratulations! You have a healthy lifestyle.</p>
            <p>Based on your answers, your vitals are within the optimal range of values.</p>
            <p>Keep up the good work!</p>
        </div>
    ) : (
        <div className='q_message'>
            <p>Your lifestyle needs improvement.</p>
            <p>Some of your vitals are not within the optimal range of values.</p>
            <p>Regular exercise can help improve blood pressure, blood sugar levels, and overall cardiovascular health.</p>
            <p>Follow a balanced diet with plenty of fruits, vegetables, whole grains, proteins, and healthy fats. </p>
        </div>
    );

    function onRestart() {
        dispatch(resetAllAction());
        dispatch(resetResultAction());
    }

    return (
        <div className='q_container'>
            <h1 className='q_title q_text-light'>REPORT</h1>
            <div className='q_result q_flex-center'>
                <div className='q_flex'>
                    <span>Username</span>
                    <span className='q_bold'>{userId || ''}</span>
                </div>

                <div className='q_flex'>
                    <span>Max Score</span>
                    <span className='q_bold'>{totalPoints || 0}</span>
                </div>

                <div className='q_flex'>
                    <span>Score Obtained</span>
                    <span className='q_bold'>{earnPoints || 0}</span>
                </div>

                <div className='q_flex'>
                    <span>Result</span>
                    <span style={{ color: `${flag ? '#2aff95' : '#ff2a66'}` }} className='q_bold'>
                        {flag ? 'Healthy' : 'Unideal'}
                    </span>
                </div>

                <div className='q_flex'>
                    <span>Analysis</span>
                </div>
                {analysisMessage}
            </div>
            <div className='q_start'>
                    <Link className='q_btn' to={'/'} onClick={() => onRestart()}>
                        RESTART
                    </Link>
                </div>
        </div>
    );
}
