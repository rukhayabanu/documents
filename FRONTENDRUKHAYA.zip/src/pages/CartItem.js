import React,{useState} from 'react'
import { connect } from "react-redux";

import './styles/CartItem.css';

import DeleteIcon from '@mui/icons-material/Delete';
import Button from '@mui/material/Button';

import * as actionTypes from '../redux/actionTypes';

function CartItem({ item, adjustQty, removeFromCart }) {
   const [input, setInput] = useState(item.qty);
  
       const onChangeHandler = (e) => {
         console.log("logging item",item);
         if(e.target.value>0)
         {
           setInput(e.target.value);
           adjustQty(item.id, e.target.value);
         } 
      
       };
      return (
               <>
             <hr/>
             <div className='s_itemContainer'>
                 <div className='s_imgc'>
                 <img src={item.image} alt={item.title}/>
                 </div>
                 <div className='s_desc'>
                     <div className='s_itemName'>
                 <h3 >{item.title}</h3>
                 </div>
                 <div className='s_itemQuantity'>
                 <label htmlFor="qty">Qty
               <input
                 min="1"
                 type="number"
                 id="qty"
                 name="qty"
                 value={input}
                 onChange={onChangeHandler}
               /></label>
                 </div>
                 <div className='s_itemdesc'>
                 <p style={{    color:'#222f3e', fontFamily: 'cursive', textAlign: 'justify'}} >{item.description}</p>
                 </div>
         <div className='s_pc'>
         <Button variant="contained" color="secondary"
       onClick={() => removeFromCart(item)}
     >
       <DeleteIcon/>Delete
     </Button>
         <h3 style={{marginTop: '1%', marginLeft: '4%'}}>₹ {item.price}</h3>
         </div>
         </div>
     </div>
     </>
 )
}

 const mapDispatchToProps = (dispatch) => {
     return{
    //  removeFromCart : (id) => dispatch({type:actionTypes.REMOVE_FROM_CART,payload:{id:id}}),
    // adjustQty : (id,qty) => dispatch({type:actionTypes.ADJUST_QTY,payload:{id:id,qty:qty}})
    //  removeFromCart: (id) => dispatch({type: actionTypes.REMOVE_FROM_CART, payload: { id }}),
    removeFromCart: (item) => dispatch({ type: actionTypes.REMOVE_FROM_CART, payload: { item } }),

    adjustQty: (id, qty) => dispatch({type: actionTypes.ADJUST_QTY, payload: { id, qty }}),
    
    }
   }
    
  export default connect(null,mapDispatchToProps)(CartItem);
    
