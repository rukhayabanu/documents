import React, { useEffect, useState } from 'react'
import { useSelector, useDispatch } from 'react-redux'
import { Navigate } from 'react-router-dom'
import Questions from './Questions'

import { MoveNextQuestion, MovePrevQuestion } from '../hooksQuiz/FetchQuestion';
import { PushAnswer } from '../hooksQuiz/setResult';


export default function Quiz() {
    const [check, setChecked] = useState(undefined)
    const result = useSelector(state => state.result.result);
    const {queue, trace } = useSelector(state => state.questions);
    const dispatch = useDispatch()

    function onNext(){
        console.log('On next click')
        if(trace<queue.length){
            dispatch(MoveNextQuestion());

            if(result.length <= trace){
                dispatch(PushAnswer(check))
            }
        }

        setChecked(undefined)

        
    }

    function onPrev(){
        if(trace > 0){
            dispatch(MovePrevQuestion());
        }
        
    }

    function onChecked(check){
        console.log(check)
        setChecked(check)
    }

    if(result.length && result.length >=queue.length){
        return <Navigate to = {'/result'} replace/>

    }


  return (
    <div className='q_container'>
        <h2 style={{ color: 'grey' }}>ASSESSMENT</h2>
              <Questions onChecked={(check) => onChecked(check)} />
            


        <div className='q_grid'>
            { trace > 0 ? <button className='q_btn q_prev' onClick={onPrev}>Prev</button> : <div/>}
            <button className='q_btn q_next' onClick={onNext}>Next</button>

        </div>

    </div>
  )
}
